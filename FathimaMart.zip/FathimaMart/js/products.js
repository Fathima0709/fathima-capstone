window.PRODUCTS = [
  {
    "id": 101,
    "name": "iPhone 16",
    "brand": "Apple",
    "category": "Mobiles",
    "price": 79999,
    "originalPrice": 100000,
    "discount": 20,
    "rating": 4.8,
    "reviewCount": 1651,
    "stock": 11,
    "description": "iPhone 16 by Apple brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Apple",
      "Category": "Mobiles",
      "Model": "iPhone 16",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 102,
    "name": "Galaxy S25",
    "brand": "Samsung",
    "category": "Mobiles",
    "price": 74999,
    "originalPrice": 83330,
    "discount": 10,
    "rating": 4.2,
    "reviewCount": 271,
    "stock": 69,
    "description": "Galaxy S25 by Samsung brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Samsung",
      "Category": "Mobiles",
      "Model": "Galaxy S25",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 103,
    "name": "12R 5G",
    "brand": "OnePlus",
    "category": "Mobiles",
    "price": 39999,
    "originalPrice": 43480,
    "discount": 8,
    "rating": 3.9,
    "reviewCount": 1746,
    "stock": 13,
    "description": "12R 5G by OnePlus brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "OnePlus",
      "Category": "Mobiles",
      "Model": "12R 5G",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1567581935884-3349723552ca?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1567581935884-3349723552ca?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 104,
    "name": "Pixel 9",
    "brand": "Google",
    "category": "Mobiles",
    "price": 69999,
    "originalPrice": 77780,
    "discount": 10,
    "rating": 4.4,
    "reviewCount": 276,
    "stock": 20,
    "description": "Pixel 9 by Google brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Google",
      "Category": "Mobiles",
      "Model": "Pixel 9",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 105,
    "name": "14 Civi",
    "brand": "Xiaomi",
    "category": "Mobiles",
    "price": 42999,
    "originalPrice": 46740,
    "discount": 8,
    "rating": 4.4,
    "reviewCount": 1658,
    "stock": 11,
    "description": "14 Civi by Xiaomi brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Xiaomi",
      "Category": "Mobiles",
      "Model": "14 Civi",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 106,
    "name": "V30 Pro",
    "brand": "Vivo",
    "category": "Mobiles",
    "price": 39999,
    "originalPrice": 43480,
    "discount": 8,
    "rating": 4.4,
    "reviewCount": 579,
    "stock": 42,
    "description": "V30 Pro by Vivo brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Vivo",
      "Category": "Mobiles",
      "Model": "V30 Pro",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1567581935884-3349723552ca?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1567581935884-3349723552ca?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 107,
    "name": "Reno 12 Pro",
    "brand": "Oppo",
    "category": "Mobiles",
    "price": 36999,
    "originalPrice": 42040,
    "discount": 12,
    "rating": 4.4,
    "reviewCount": 2372,
    "stock": 44,
    "description": "Reno 12 Pro by Oppo brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Oppo",
      "Category": "Mobiles",
      "Model": "Reno 12 Pro",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 108,
    "name": "GT 6",
    "brand": "Realme",
    "category": "Mobiles",
    "price": 42999,
    "originalPrice": 48860,
    "discount": 12,
    "rating": 3.9,
    "reviewCount": 2373,
    "stock": 29,
    "description": "GT 6 by Realme brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Realme",
      "Category": "Mobiles",
      "Model": "GT 6",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 109,
    "name": "MacBook Air M3",
    "brand": "Apple",
    "category": "Laptops",
    "price": 99999,
    "originalPrice": 111110,
    "discount": 10,
    "rating": 4.4,
    "reviewCount": 291,
    "stock": 12,
    "description": "MacBook Air M3 by Apple brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Apple",
      "Category": "Laptops",
      "Model": "MacBook Air M3",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 110,
    "name": "Inspiron 14",
    "brand": "Dell",
    "category": "Laptops",
    "price": 64999,
    "originalPrice": 76470,
    "discount": 15,
    "rating": 4.3,
    "reviewCount": 2211,
    "stock": 59,
    "description": "Inspiron 14 by Dell brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Dell",
      "Category": "Laptops",
      "Model": "Inspiron 14",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 111,
    "name": "Pavilion Plus 14",
    "brand": "HP",
    "category": "Laptops",
    "price": 67999,
    "originalPrice": 90670,
    "discount": 25,
    "rating": 4.4,
    "reviewCount": 1890,
    "stock": 51,
    "description": "Pavilion Plus 14 by HP brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "HP",
      "Category": "Laptops",
      "Model": "Pavilion Plus 14",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1517336714739-489689fd1ca8?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1517336714739-489689fd1ca8?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 112,
    "name": "IdeaPad Slim 5",
    "brand": "Lenovo",
    "category": "Laptops",
    "price": 58999,
    "originalPrice": 69410,
    "discount": 15,
    "rating": 4.7,
    "reviewCount": 1033,
    "stock": 15,
    "description": "IdeaPad Slim 5 by Lenovo brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Lenovo",
      "Category": "Laptops",
      "Model": "IdeaPad Slim 5",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 113,
    "name": "Vivobook 15",
    "brand": "ASUS",
    "category": "Laptops",
    "price": 54999,
    "originalPrice": 67070,
    "discount": 18,
    "rating": 4.4,
    "reviewCount": 1440,
    "stock": 62,
    "description": "Vivobook 15 by ASUS brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "ASUS",
      "Category": "Laptops",
      "Model": "Vivobook 15",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 114,
    "name": "Swift Go 14",
    "brand": "Acer",
    "category": "Laptops",
    "price": 62999,
    "originalPrice": 70000,
    "discount": 10,
    "rating": 3.9,
    "reviewCount": 1746,
    "stock": 26,
    "description": "Swift Go 14 by Acer brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Acer",
      "Category": "Laptops",
      "Model": "Swift Go 14",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1517336714739-489689fd1ca8?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1517336714739-489689fd1ca8?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 115,
    "name": "Modern 14",
    "brand": "MSI",
    "category": "Laptops",
    "price": 61999,
    "originalPrice": 70450,
    "discount": 12,
    "rating": 4.8,
    "reviewCount": 1761,
    "stock": 10,
    "description": "Modern 14 by MSI brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "MSI",
      "Category": "Laptops",
      "Model": "Modern 14",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 116,
    "name": "iPad Air",
    "brand": "Apple",
    "category": "Tablets",
    "price": 59999,
    "originalPrice": 75000,
    "discount": 20,
    "rating": 4.2,
    "reviewCount": 1468,
    "stock": 68,
    "description": "iPad Air by Apple brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Apple",
      "Category": "Tablets",
      "Model": "iPad Air",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 117,
    "name": "Galaxy Tab S9 FE",
    "brand": "Samsung",
    "category": "Tablets",
    "price": 39999,
    "originalPrice": 53330,
    "discount": 25,
    "rating": 3.9,
    "reviewCount": 417,
    "stock": 39,
    "description": "Galaxy Tab S9 FE by Samsung brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Samsung",
      "Category": "Tablets",
      "Model": "Galaxy Tab S9 FE",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 118,
    "name": "Pad 2",
    "brand": "OnePlus",
    "category": "Tablets",
    "price": 39999,
    "originalPrice": 44440,
    "discount": 10,
    "rating": 3.9,
    "reviewCount": 1302,
    "stock": 62,
    "description": "Pad 2 by OnePlus brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "OnePlus",
      "Category": "Tablets",
      "Model": "Pad 2",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 119,
    "name": "Pad 6",
    "brand": "Xiaomi",
    "category": "Tablets",
    "price": 28999,
    "originalPrice": 37180,
    "discount": 22,
    "rating": 4.8,
    "reviewCount": 1455,
    "stock": 7,
    "description": "Pad 6 by Xiaomi brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Xiaomi",
      "Category": "Tablets",
      "Model": "Pad 6",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 120,
    "name": "Tab P12",
    "brand": "Lenovo",
    "category": "Tablets",
    "price": 32999,
    "originalPrice": 41250,
    "discount": 20,
    "rating": 4.0,
    "reviewCount": 513,
    "stock": 68,
    "description": "Tab P12 by Lenovo brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Lenovo",
      "Category": "Tablets",
      "Model": "Tab P12",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 121,
    "name": "Pad 2",
    "brand": "Realme",
    "category": "Tablets",
    "price": 22999,
    "originalPrice": 27060,
    "discount": 15,
    "rating": 4.6,
    "reviewCount": 563,
    "stock": 36,
    "description": "Pad 2 by Realme brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Realme",
      "Category": "Tablets",
      "Model": "Pad 2",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 122,
    "name": "WH-1000XM5",
    "brand": "Sony",
    "category": "Headphones",
    "price": 29990,
    "originalPrice": 38450,
    "discount": 22,
    "rating": 4.8,
    "reviewCount": 2067,
    "stock": 15,
    "description": "WH-1000XM5 by Sony brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Sony",
      "Category": "Headphones",
      "Model": "WH-1000XM5",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 123,
    "name": "QuietComfort",
    "brand": "Bose",
    "category": "Headphones",
    "price": 24990,
    "originalPrice": 33320,
    "discount": 25,
    "rating": 4.2,
    "reviewCount": 1172,
    "stock": 22,
    "description": "QuietComfort by Bose brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Bose",
      "Category": "Headphones",
      "Model": "QuietComfort",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 124,
    "name": "Tune 770NC",
    "brand": "JBL",
    "category": "Headphones",
    "price": 6999,
    "originalPrice": 8540,
    "discount": 18,
    "rating": 4.6,
    "reviewCount": 1503,
    "stock": 53,
    "description": "Tune 770NC by JBL brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "JBL",
      "Category": "Headphones",
      "Model": "Tune 770NC",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 125,
    "name": "Accentum Wireless",
    "brand": "Sennheiser",
    "category": "Headphones",
    "price": 10990,
    "originalPrice": 12490,
    "discount": 12,
    "rating": 3.9,
    "reviewCount": 653,
    "stock": 34,
    "description": "Accentum Wireless by Sennheiser brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Sennheiser",
      "Category": "Headphones",
      "Model": "Accentum Wireless",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 126,
    "name": "Rockerz 550",
    "brand": "Boat",
    "category": "Headphones",
    "price": 1999,
    "originalPrice": 2170,
    "discount": 8,
    "rating": 4.3,
    "reviewCount": 780,
    "stock": 38,
    "description": "Rockerz 550 by Boat brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Boat",
      "Category": "Headphones",
      "Model": "Rockerz 550",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 127,
    "name": "Soundcore Q20i",
    "brand": "Anker",
    "category": "Headphones",
    "price": 4499,
    "originalPrice": 4890,
    "discount": 8,
    "rating": 4.0,
    "reviewCount": 2223,
    "stock": 52,
    "description": "Soundcore Q20i by Anker brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Anker",
      "Category": "Headphones",
      "Model": "Soundcore Q20i",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 128,
    "name": "AirPods Pro 2",
    "brand": "Apple",
    "category": "Earbuds",
    "price": 24900,
    "originalPrice": 31120,
    "discount": 20,
    "rating": 4.8,
    "reviewCount": 2145,
    "stock": 11,
    "description": "AirPods Pro 2 by Apple brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Apple",
      "Category": "Earbuds",
      "Model": "AirPods Pro 2",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 129,
    "name": "Galaxy Buds3 Pro",
    "brand": "Samsung",
    "category": "Earbuds",
    "price": 17999,
    "originalPrice": 23080,
    "discount": 22,
    "rating": 4.2,
    "reviewCount": 1648,
    "stock": 18,
    "description": "Galaxy Buds3 Pro by Samsung brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Samsung",
      "Category": "Earbuds",
      "Model": "Galaxy Buds3 Pro",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 130,
    "name": "Buds Pro 3",
    "brand": "OnePlus",
    "category": "Earbuds",
    "price": 11999,
    "originalPrice": 15380,
    "discount": 22,
    "rating": 3.9,
    "reviewCount": 309,
    "stock": 31,
    "description": "Buds Pro 3 by OnePlus brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "OnePlus",
      "Category": "Earbuds",
      "Model": "Buds Pro 3",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 131,
    "name": "Ear",
    "brand": "Nothing",
    "category": "Earbuds",
    "price": 8999,
    "originalPrice": 10230,
    "discount": 12,
    "rating": 3.9,
    "reviewCount": 249,
    "stock": 18,
    "description": "Ear by Nothing brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Nothing",
      "Category": "Earbuds",
      "Model": "Ear",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 132,
    "name": "Live Beam 3",
    "brand": "JBL",
    "category": "Earbuds",
    "price": 13999,
    "originalPrice": 15910,
    "discount": 12,
    "rating": 4.4,
    "reviewCount": 1523,
    "stock": 8,
    "description": "Live Beam 3 by JBL brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "JBL",
      "Category": "Earbuds",
      "Model": "Live Beam 3",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 133,
    "name": "Buds Air 6 Pro",
    "brand": "Realme",
    "category": "Earbuds",
    "price": 4999,
    "originalPrice": 5880,
    "discount": 15,
    "rating": 4.5,
    "reviewCount": 642,
    "stock": 37,
    "description": "Buds Air 6 Pro by Realme brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Realme",
      "Category": "Earbuds",
      "Model": "Buds Air 6 Pro",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 134,
    "name": "Watch Series 10",
    "brand": "Apple",
    "category": "Smart Watches",
    "price": 46900,
    "originalPrice": 58620,
    "discount": 20,
    "rating": 4.3,
    "reviewCount": 506,
    "stock": 67,
    "description": "Watch Series 10 by Apple brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Apple",
      "Category": "Smart Watches",
      "Model": "Watch Series 10",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1546868871-7041f2a55e0a?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1546868871-7041f2a55e0a?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 135,
    "name": "Galaxy Watch7",
    "brand": "Samsung",
    "category": "Smart Watches",
    "price": 32999,
    "originalPrice": 44000,
    "discount": 25,
    "rating": 4.3,
    "reviewCount": 385,
    "stock": 23,
    "description": "Galaxy Watch7 by Samsung brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Samsung",
      "Category": "Smart Watches",
      "Model": "Galaxy Watch7",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 136,
    "name": "Forerunner 165",
    "brand": "Garmin",
    "category": "Smart Watches",
    "price": 29990,
    "originalPrice": 37490,
    "discount": 20,
    "rating": 4.6,
    "reviewCount": 1994,
    "stock": 25,
    "description": "Forerunner 165 by Garmin brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Garmin",
      "Category": "Smart Watches",
      "Model": "Forerunner 165",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1546868871-7041f2a55e0a?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1546868871-7041f2a55e0a?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 137,
    "name": "ColorFit Pro 6",
    "brand": "Noise",
    "category": "Smart Watches",
    "price": 3499,
    "originalPrice": 3800,
    "discount": 8,
    "rating": 4.0,
    "reviewCount": 2197,
    "stock": 51,
    "description": "ColorFit Pro 6 by Noise brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Noise",
      "Category": "Smart Watches",
      "Model": "ColorFit Pro 6",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 138,
    "name": "Lunar Pro",
    "brand": "boAt",
    "category": "Smart Watches",
    "price": 3999,
    "originalPrice": 4350,
    "discount": 8,
    "rating": 4.6,
    "reviewCount": 1254,
    "stock": 16,
    "description": "Lunar Pro by boAt brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "boAt",
      "Category": "Smart Watches",
      "Model": "Lunar Pro",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1546868871-7041f2a55e0a?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1546868871-7041f2a55e0a?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 139,
    "name": "Active",
    "brand": "Amazfit",
    "category": "Smart Watches",
    "price": 11999,
    "originalPrice": 15000,
    "discount": 20,
    "rating": 4.8,
    "reviewCount": 1490,
    "stock": 33,
    "description": "Active by Amazfit brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Amazfit",
      "Category": "Smart Watches",
      "Model": "Active",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 140,
    "name": "MX Master 3S",
    "brand": "Logitech",
    "category": "Computer Accessories",
    "price": 8995,
    "originalPrice": 11240,
    "discount": 20,
    "rating": 4.5,
    "reviewCount": 833,
    "stock": 35,
    "description": "MX Master 3S by Logitech brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Logitech",
      "Category": "Computer Accessories",
      "Model": "MX Master 3S",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 141,
    "name": "K380 Keyboard",
    "brand": "Logitech",
    "category": "Computer Accessories",
    "price": 3495,
    "originalPrice": 4110,
    "discount": 15,
    "rating": 4.0,
    "reviewCount": 2052,
    "stock": 50,
    "description": "K380 Keyboard by Logitech brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Logitech",
      "Category": "Computer Accessories",
      "Model": "K380 Keyboard",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 142,
    "name": "Wireless Mouse 250",
    "brand": "HP",
    "category": "Computer Accessories",
    "price": 1299,
    "originalPrice": 1410,
    "discount": 8,
    "rating": 4.7,
    "reviewCount": 1968,
    "stock": 38,
    "description": "Wireless Mouse 250 by HP brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "HP",
      "Category": "Computer Accessories",
      "Model": "Wireless Mouse 250",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 143,
    "name": "KM3322W Combo",
    "brand": "Dell",
    "category": "Computer Accessories",
    "price": 1999,
    "originalPrice": 2500,
    "discount": 20,
    "rating": 4.3,
    "reviewCount": 1465,
    "stock": 51,
    "description": "KM3322W Combo by Dell brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Dell",
      "Category": "Computer Accessories",
      "Model": "KM3322W Combo",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 144,
    "name": "Archer T3U Plus",
    "brand": "TP-Link",
    "category": "Computer Accessories",
    "price": 1699,
    "originalPrice": 2000,
    "discount": 15,
    "rating": 3.9,
    "reviewCount": 1959,
    "stock": 30,
    "description": "Archer T3U Plus by TP-Link brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "TP-Link",
      "Category": "Computer Accessories",
      "Model": "Archer T3U Plus",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 145,
    "name": "Extreme 1TB SSD",
    "brand": "SanDisk",
    "category": "Computer Accessories",
    "price": 8999,
    "originalPrice": 10590,
    "discount": 15,
    "rating": 4.3,
    "reviewCount": 41,
    "stock": 66,
    "description": "Extreme 1TB SSD by SanDisk brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "SanDisk",
      "Category": "Computer Accessories",
      "Model": "Extreme 1TB SSD",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 146,
    "name": "PlayStation 5 Slim",
    "brand": "Sony",
    "category": "Gaming",
    "price": 54990,
    "originalPrice": 61100,
    "discount": 10,
    "rating": 4.7,
    "reviewCount": 525,
    "stock": 54,
    "description": "PlayStation 5 Slim by Sony brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Sony",
      "Category": "Gaming",
      "Model": "PlayStation 5 Slim",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 147,
    "name": "Xbox Series S",
    "brand": "Microsoft",
    "category": "Gaming",
    "price": 34990,
    "originalPrice": 46650,
    "discount": 25,
    "rating": 4.8,
    "reviewCount": 1811,
    "stock": 47,
    "description": "Xbox Series S by Microsoft brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Microsoft",
      "Category": "Gaming",
      "Model": "Xbox Series S",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 148,
    "name": "G502 X",
    "brand": "Logitech",
    "category": "Gaming",
    "price": 8999,
    "originalPrice": 11540,
    "discount": 22,
    "rating": 4.3,
    "reviewCount": 381,
    "stock": 25,
    "description": "G502 X by Logitech brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Logitech",
      "Category": "Gaming",
      "Model": "G502 X",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 149,
    "name": "BlackShark V2 X",
    "brand": "Razer",
    "category": "Gaming",
    "price": 4999,
    "originalPrice": 5680,
    "discount": 12,
    "rating": 3.8,
    "reviewCount": 1940,
    "stock": 23,
    "description": "BlackShark V2 X by Razer brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Razer",
      "Category": "Gaming",
      "Model": "BlackShark V2 X",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 150,
    "name": "K617 Fizz",
    "brand": "Redragon",
    "category": "Gaming",
    "price": 2799,
    "originalPrice": 3730,
    "discount": 25,
    "rating": 4.5,
    "reviewCount": 1469,
    "stock": 24,
    "description": "K617 Fizz by Redragon brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Redragon",
      "Category": "Gaming",
      "Model": "K617 Fizz",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 151,
    "name": "TUF Gaming Mouse",
    "brand": "ASUS",
    "category": "Gaming",
    "price": 2999,
    "originalPrice": 3410,
    "discount": 12,
    "rating": 3.8,
    "reviewCount": 454,
    "stock": 72,
    "description": "TUF Gaming Mouse by ASUS brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "ASUS",
      "Category": "Gaming",
      "Model": "TUF Gaming Mouse",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 152,
    "name": "511 Slim Jeans",
    "brand": "Levi's",
    "category": "Men's Fashion",
    "price": 2999,
    "originalPrice": 3840,
    "discount": 22,
    "rating": 4.9,
    "reviewCount": 831,
    "stock": 32,
    "description": "511 Slim Jeans by Levi's brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Levi's",
      "Category": "Men's Fashion",
      "Model": "511 Slim Jeans",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 153,
    "name": "Formal Shirt",
    "brand": "Peter England",
    "category": "Men's Fashion",
    "price": 1799,
    "originalPrice": 2190,
    "discount": 18,
    "rating": 4.0,
    "reviewCount": 2086,
    "stock": 35,
    "description": "Formal Shirt by Peter England brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Peter England",
      "Category": "Men's Fashion",
      "Model": "Formal Shirt",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 154,
    "name": "Oxford Shirt",
    "brand": "Allen Solly",
    "category": "Men's Fashion",
    "price": 1999,
    "originalPrice": 2500,
    "discount": 20,
    "rating": 4.1,
    "reviewCount": 1750,
    "stock": 21,
    "description": "Oxford Shirt by Allen Solly brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Allen Solly",
      "Category": "Men's Fashion",
      "Model": "Oxford Shirt",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 155,
    "name": "Polo T-Shirt",
    "brand": "Van Heusen",
    "category": "Men's Fashion",
    "price": 1599,
    "originalPrice": 2000,
    "discount": 20,
    "rating": 4.8,
    "reviewCount": 2150,
    "stock": 58,
    "description": "Polo T-Shirt by Van Heusen brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Van Heusen",
      "Category": "Men's Fashion",
      "Model": "Polo T-Shirt",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 156,
    "name": "Casual Jacket",
    "brand": "Roadster",
    "category": "Men's Fashion",
    "price": 2499,
    "originalPrice": 2840,
    "discount": 12,
    "rating": 4.4,
    "reviewCount": 2178,
    "stock": 70,
    "description": "Casual Jacket by Roadster brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Roadster",
      "Category": "Men's Fashion",
      "Model": "Casual Jacket",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 157,
    "name": "Chino Trousers",
    "brand": "U.S. Polo Assn.",
    "category": "Men's Fashion",
    "price": 2299,
    "originalPrice": 3070,
    "discount": 25,
    "rating": 4.7,
    "reviewCount": 50,
    "stock": 24,
    "description": "Chino Trousers by U.S. Polo Assn. brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "U.S. Polo Assn.",
      "Category": "Men's Fashion",
      "Model": "Chino Trousers",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 158,
    "name": "Printed Kurta",
    "brand": "Biba",
    "category": "Women's Fashion",
    "price": 1799,
    "originalPrice": 2040,
    "discount": 12,
    "rating": 4.3,
    "reviewCount": 526,
    "stock": 12,
    "description": "Printed Kurta by Biba brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Biba",
      "Category": "Women's Fashion",
      "Model": "Printed Kurta",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 159,
    "name": "Embroidered Kurta Set",
    "brand": "W",
    "category": "Women's Fashion",
    "price": 3299,
    "originalPrice": 4400,
    "discount": 25,
    "rating": 4.7,
    "reviewCount": 468,
    "stock": 12,
    "description": "Embroidered Kurta Set by W brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "W",
      "Category": "Women's Fashion",
      "Model": "Embroidered Kurta Set",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 160,
    "name": "Anarkali Kurta",
    "brand": "Libas",
    "category": "Women's Fashion",
    "price": 2199,
    "originalPrice": 2590,
    "discount": 15,
    "rating": 4.1,
    "reviewCount": 434,
    "stock": 69,
    "description": "Anarkali Kurta by Libas brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Libas",
      "Category": "Women's Fashion",
      "Model": "Anarkali Kurta",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 161,
    "name": "Straight Kurta",
    "brand": "Aurelia",
    "category": "Women's Fashion",
    "price": 1599,
    "originalPrice": 1740,
    "discount": 8,
    "rating": 4.6,
    "reviewCount": 293,
    "stock": 61,
    "description": "Straight Kurta by Aurelia brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Aurelia",
      "Category": "Women's Fashion",
      "Model": "Straight Kurta",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 162,
    "name": "Casual Dress",
    "brand": "FabAlley",
    "category": "Women's Fashion",
    "price": 2499,
    "originalPrice": 2940,
    "discount": 15,
    "rating": 4.6,
    "reviewCount": 1886,
    "stock": 70,
    "description": "Casual Dress by FabAlley brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "FabAlley",
      "Category": "Women's Fashion",
      "Model": "Casual Dress",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 163,
    "name": "Denim Jacket",
    "brand": "ONLY",
    "category": "Women's Fashion",
    "price": 2999,
    "originalPrice": 4000,
    "discount": 25,
    "rating": 4.4,
    "reviewCount": 1048,
    "stock": 71,
    "description": "Denim Jacket by ONLY brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "ONLY",
      "Category": "Women's Fashion",
      "Model": "Denim Jacket",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 164,
    "name": "Revolution 7 Running Shoes",
    "brand": "Nike",
    "category": "Shoes",
    "price": 4995,
    "originalPrice": 5880,
    "discount": 15,
    "rating": 4.7,
    "reviewCount": 595,
    "stock": 58,
    "description": "Revolution 7 Running Shoes by Nike brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Nike",
      "Category": "Shoes",
      "Model": "Revolution 7 Running Shoes",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 165,
    "name": "Duramo SL",
    "brand": "Adidas",
    "category": "Shoes",
    "price": 4599,
    "originalPrice": 5900,
    "discount": 22,
    "rating": 4.3,
    "reviewCount": 331,
    "stock": 35,
    "description": "Duramo SL by Adidas brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Adidas",
      "Category": "Shoes",
      "Model": "Duramo SL",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 166,
    "name": "FlexFocus Lite",
    "brand": "Puma",
    "category": "Shoes",
    "price": 3499,
    "originalPrice": 3890,
    "discount": 10,
    "rating": 4.0,
    "reviewCount": 1274,
    "stock": 20,
    "description": "FlexFocus Lite by Puma brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Puma",
      "Category": "Shoes",
      "Model": "FlexFocus Lite",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 167,
    "name": "Go Walk Flex",
    "brand": "Skechers",
    "category": "Shoes",
    "price": 5999,
    "originalPrice": 7500,
    "discount": 20,
    "rating": 4.0,
    "reviewCount": 596,
    "stock": 64,
    "description": "Go Walk Flex by Skechers brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Skechers",
      "Category": "Shoes",
      "Model": "Go Walk Flex",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 168,
    "name": "Oxyfit Running Shoes",
    "brand": "Campus",
    "category": "Shoes",
    "price": 1799,
    "originalPrice": 2000,
    "discount": 10,
    "rating": 4.2,
    "reviewCount": 2029,
    "stock": 25,
    "description": "Oxyfit Running Shoes by Campus brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Campus",
      "Category": "Shoes",
      "Model": "Oxyfit Running Shoes",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 169,
    "name": "Energen Lite",
    "brand": "Reebok",
    "category": "Shoes",
    "price": 3999,
    "originalPrice": 4540,
    "discount": 12,
    "rating": 4.6,
    "reviewCount": 2145,
    "stock": 56,
    "description": "Energen Lite by Reebok brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Reebok",
      "Category": "Shoes",
      "Model": "Energen Lite",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 170,
    "name": "Urban Groove Backpack",
    "brand": "American Tourister",
    "category": "Bags",
    "price": 1999,
    "originalPrice": 2560,
    "discount": 22,
    "rating": 4.0,
    "reviewCount": 1338,
    "stock": 16,
    "description": "Urban Groove Backpack by American Tourister brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "American Tourister",
      "Category": "Bags",
      "Model": "Urban Groove Backpack",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 171,
    "name": "Brat Backpack",
    "brand": "Skybags",
    "category": "Bags",
    "price": 1499,
    "originalPrice": 1630,
    "discount": 8,
    "rating": 4.2,
    "reviewCount": 1912,
    "stock": 61,
    "description": "Brat Backpack by Skybags brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Skybags",
      "Category": "Bags",
      "Model": "Brat Backpack",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 172,
    "name": "45L Rucksack",
    "brand": "Wildcraft",
    "category": "Bags",
    "price": 2699,
    "originalPrice": 3460,
    "discount": 22,
    "rating": 4.2,
    "reviewCount": 1244,
    "stock": 70,
    "description": "45L Rucksack by Wildcraft brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Wildcraft",
      "Category": "Bags",
      "Model": "45L Rucksack",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 173,
    "name": "Laptop Backpack",
    "brand": "F Gear",
    "category": "Bags",
    "price": 1899,
    "originalPrice": 2110,
    "discount": 10,
    "rating": 4.9,
    "reviewCount": 970,
    "stock": 18,
    "description": "Laptop Backpack by F Gear brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "F Gear",
      "Category": "Bags",
      "Model": "Laptop Backpack",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 174,
    "name": "Transit Backpack",
    "brand": "Mokobara",
    "category": "Bags",
    "price": 3999,
    "originalPrice": 4880,
    "discount": 18,
    "rating": 4.1,
    "reviewCount": 777,
    "stock": 39,
    "description": "Transit Backpack by Mokobara brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Mokobara",
      "Category": "Bags",
      "Model": "Transit Backpack",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 175,
    "name": "Women Tote Bag",
    "brand": "Lavie",
    "category": "Bags",
    "price": 2299,
    "originalPrice": 2950,
    "discount": 22,
    "rating": 4.7,
    "reviewCount": 1093,
    "stock": 56,
    "description": "Women Tote Bag by Lavie brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Lavie",
      "Category": "Bags",
      "Model": "Women Tote Bag",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 176,
    "name": "Gentle Skin Cleanser",
    "brand": "Cetaphil",
    "category": "Beauty",
    "price": 699,
    "originalPrice": 930,
    "discount": 25,
    "rating": 4.6,
    "reviewCount": 400,
    "stock": 40,
    "description": "Gentle Skin Cleanser from Cetaphil, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal to combination",
      "Ingredients": "Dermatologically selected actives",
      "Net Quantity": "100 ml",
      "Benefits": "Hydration and skin support",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Cetaphil",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 177,
    "name": "Vitamin C 10% Face Serum",
    "brand": "Minimalist",
    "category": "Beauty",
    "price": 699,
    "originalPrice": 790,
    "discount": 12,
    "rating": 4.3,
    "reviewCount": 330,
    "stock": 39,
    "description": "Vitamin C 10% Face Serum from Minimalist, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal to combination",
      "Ingredients": "Dermatologically selected actives",
      "Net Quantity": "100 ml",
      "Benefits": "Hydration and skin support",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Minimalist",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 178,
    "name": "Niacinamide 10% Serum",
    "brand": "Minimalist",
    "category": "Beauty",
    "price": 599,
    "originalPrice": 670,
    "discount": 10,
    "rating": 4.7,
    "reviewCount": 377,
    "stock": 33,
    "description": "Niacinamide 10% Serum from Minimalist, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal to combination",
      "Ingredients": "Dermatologically selected actives",
      "Net Quantity": "100 ml",
      "Benefits": "Hydration and skin support",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Minimalist",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 179,
    "name": "Ultra Sheer Sunscreen SPF 50+",
    "brand": "Neutrogena",
    "category": "Beauty",
    "price": 699,
    "originalPrice": 850,
    "discount": 18,
    "rating": 4.7,
    "reviewCount": 1892,
    "stock": 6,
    "description": "Ultra Sheer Sunscreen SPF 50+ from Neutrogena, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal to combination",
      "Ingredients": "Dermatologically selected actives",
      "Net Quantity": "100 ml",
      "Benefits": "Hydration and skin support",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Neutrogena",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 180,
    "name": "Moisturizing Cream",
    "brand": "CeraVe",
    "category": "Beauty",
    "price": 1299,
    "originalPrice": 1670,
    "discount": 22,
    "rating": 4.8,
    "reviewCount": 1131,
    "stock": 21,
    "description": "Moisturizing Cream from CeraVe, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal skin",
      "Ingredients": "Gentle personal-care formula",
      "Net Quantity": "Varies by product",
      "Benefits": "Daily personal care",
      "Suitable For": "Adults",
      "Brand": "CeraVe",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 181,
    "name": "Absolute Skin Dew Serum",
    "brand": "Lakme",
    "category": "Beauty",
    "price": 899,
    "originalPrice": 1060,
    "discount": 15,
    "rating": 4.8,
    "reviewCount": 695,
    "stock": 38,
    "description": "Absolute Skin Dew Serum from Lakme, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal to combination",
      "Ingredients": "Dermatologically selected actives",
      "Net Quantity": "100 ml",
      "Benefits": "Hydration and skin support",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Lakme",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 182,
    "name": "Fit Me Matte Foundation",
    "brand": "Maybelline",
    "category": "Beauty",
    "price": 599,
    "originalPrice": 680,
    "discount": 12,
    "rating": 4.0,
    "reviewCount": 1311,
    "stock": 44,
    "description": "Fit Me Matte Foundation from Maybelline, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Maybelline",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 183,
    "name": "9 to 5 Primer + Matte Lipstick",
    "brand": "Lakme",
    "category": "Beauty",
    "price": 599,
    "originalPrice": 700,
    "discount": 15,
    "rating": 4.1,
    "reviewCount": 2082,
    "stock": 27,
    "description": "9 to 5 Primer + Matte Lipstick from Lakme, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Lakme",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 184,
    "name": "Lifter Gloss",
    "brand": "Maybelline",
    "category": "Beauty",
    "price": 749,
    "originalPrice": 940,
    "discount": 20,
    "rating": 4.7,
    "reviewCount": 1059,
    "stock": 9,
    "description": "Lifter Gloss from Maybelline, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Maybelline",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 185,
    "name": "Eyeconic Kajal",
    "brand": "Lakme",
    "category": "Beauty",
    "price": 199,
    "originalPrice": 220,
    "discount": 8,
    "rating": 4.6,
    "reviewCount": 2291,
    "stock": 29,
    "description": "Eyeconic Kajal from Lakme, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Lakme",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 186,
    "name": "Hypercurl Mascara",
    "brand": "Maybelline",
    "category": "Beauty",
    "price": 399,
    "originalPrice": 530,
    "discount": 25,
    "rating": 4.1,
    "reviewCount": 1865,
    "stock": 18,
    "description": "Hypercurl Mascara from Maybelline, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Maybelline",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 187,
    "name": "Professional Blush",
    "brand": "Swiss Beauty",
    "category": "Beauty",
    "price": 349,
    "originalPrice": 470,
    "discount": 25,
    "rating": 4.4,
    "reviewCount": 1644,
    "stock": 69,
    "description": "Professional Blush from Swiss Beauty, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Swiss Beauty",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 188,
    "name": "Eyes Can Kill Eyeshadow Palette",
    "brand": "MARS",
    "category": "Beauty",
    "price": 499,
    "originalPrice": 590,
    "discount": 15,
    "rating": 4.9,
    "reviewCount": 1437,
    "stock": 30,
    "description": "Eyes Can Kill Eyeshadow Palette from MARS, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "MARS",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 189,
    "name": "Makeup Brush Set",
    "brand": "Colorbar",
    "category": "Beauty",
    "price": 899,
    "originalPrice": 1150,
    "discount": 22,
    "rating": 4.9,
    "reviewCount": 256,
    "stock": 21,
    "description": "Makeup Brush Set from Colorbar, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Colorbar",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 190,
    "name": "Makeup Blender Sponge",
    "brand": "MARS",
    "category": "Beauty",
    "price": 199,
    "originalPrice": 220,
    "discount": 10,
    "rating": 4.5,
    "reviewCount": 1080,
    "stock": 60,
    "description": "Makeup Blender Sponge from MARS, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "All skin types",
      "Ingredients": "Cosmetic-grade ingredients",
      "Net Quantity": "Varies by product",
      "Benefits": "Buildable everyday coverage",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "MARS",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 191,
    "name": "Total Repair 5 Shampoo",
    "brand": "L'Oréal",
    "category": "Beauty",
    "price": 449,
    "originalPrice": 490,
    "discount": 8,
    "rating": 3.9,
    "reviewCount": 1594,
    "stock": 69,
    "description": "Total Repair 5 Shampoo from L'Oréal, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Hair Type": "All hair types",
      "Ingredients": "Nourishing haircare blend",
      "Benefits": "Cleanses and conditions hair",
      "Net Quantity": "Varies by product",
      "Brand": "L'Oréal",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 192,
    "name": "Intense Repair Conditioner",
    "brand": "Dove",
    "category": "Beauty",
    "price": 299,
    "originalPrice": 350,
    "discount": 15,
    "rating": 4.6,
    "reviewCount": 219,
    "stock": 63,
    "description": "Intense Repair Conditioner from Dove, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Hair Type": "All hair types",
      "Ingredients": "Nourishing haircare blend",
      "Benefits": "Cleanses and conditions hair",
      "Net Quantity": "Varies by product",
      "Brand": "Dove",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 193,
    "name": "Extraordinary Oil Serum",
    "brand": "L'Oréal",
    "category": "Beauty",
    "price": 699,
    "originalPrice": 790,
    "discount": 12,
    "rating": 4.1,
    "reviewCount": 48,
    "stock": 38,
    "description": "Extraordinary Oil Serum from L'Oréal, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal to combination",
      "Ingredients": "Dermatologically selected actives",
      "Net Quantity": "100 ml",
      "Benefits": "Hydration and skin support",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "L'Oréal",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 194,
    "name": "Advansed Coconut Hair Oil",
    "brand": "Parachute",
    "category": "Beauty",
    "price": 249,
    "originalPrice": 310,
    "discount": 20,
    "rating": 4.9,
    "reviewCount": 2274,
    "stock": 46,
    "description": "Advansed Coconut Hair Oil from Parachute, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Hair Type": "All hair types",
      "Ingredients": "Nourishing haircare blend",
      "Benefits": "Cleanses and conditions hair",
      "Net Quantity": "Varies by product",
      "Brand": "Parachute",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 195,
    "name": "Argan Hair Mask",
    "brand": "Mamaearth",
    "category": "Beauty",
    "price": 599,
    "originalPrice": 650,
    "discount": 8,
    "rating": 4.9,
    "reviewCount": 1301,
    "stock": 32,
    "description": "Argan Hair Mask from Mamaearth, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Hair Type": "All hair types",
      "Ingredients": "Nourishing haircare blend",
      "Benefits": "Cleanses and conditions hair",
      "Net Quantity": "Varies by product",
      "Brand": "Mamaearth",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 196,
    "name": "Hair Serum",
    "brand": "Streax",
    "category": "Beauty",
    "price": 299,
    "originalPrice": 340,
    "discount": 12,
    "rating": 3.8,
    "reviewCount": 1597,
    "stock": 15,
    "description": "Hair Serum from Streax, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal to combination",
      "Ingredients": "Dermatologically selected actives",
      "Net Quantity": "100 ml",
      "Benefits": "Hydration and skin support",
      "Suitable For": "Adults",
      "Expiry": "See pack",
      "Brand": "Streax",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 197,
    "name": "Anti-Dandruff Shampoo",
    "brand": "Head & Shoulders",
    "category": "Beauty",
    "price": 399,
    "originalPrice": 490,
    "discount": 18,
    "rating": 4.4,
    "reviewCount": 857,
    "stock": 36,
    "description": "Anti-Dandruff Shampoo from Head & Shoulders, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Hair Type": "All hair types",
      "Ingredients": "Nourishing haircare blend",
      "Benefits": "Cleanses and conditions hair",
      "Net Quantity": "Varies by product",
      "Brand": "Head & Shoulders",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 198,
    "name": "Keratin Smooth Styling Cream",
    "brand": "TRESemmé",
    "category": "Beauty",
    "price": 499,
    "originalPrice": 540,
    "discount": 8,
    "rating": 3.9,
    "reviewCount": 401,
    "stock": 23,
    "description": "Keratin Smooth Styling Cream from TRESemmé, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Hair Type": "All hair types",
      "Ingredients": "Nourishing haircare blend",
      "Benefits": "Cleanses and conditions hair",
      "Net Quantity": "Varies by product",
      "Brand": "TRESemmé",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 199,
    "name": "Men Deep Impact Body Wash",
    "brand": "Nivea",
    "category": "Beauty",
    "price": 349,
    "originalPrice": 380,
    "discount": 8,
    "rating": 4.2,
    "reviewCount": 1261,
    "stock": 43,
    "description": "Men Deep Impact Body Wash from Nivea, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal skin",
      "Ingredients": "Gentle personal-care formula",
      "Net Quantity": "Varies by product",
      "Benefits": "Daily personal care",
      "Suitable For": "Adults",
      "Brand": "Nivea",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 200,
    "name": "Body Lotion Cocoa Nourish",
    "brand": "Nivea",
    "category": "Beauty",
    "price": 399,
    "originalPrice": 440,
    "discount": 10,
    "rating": 4.4,
    "reviewCount": 2201,
    "stock": 24,
    "description": "Body Lotion Cocoa Nourish from Nivea, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal skin",
      "Ingredients": "Gentle personal-care formula",
      "Net Quantity": "Varies by product",
      "Benefits": "Daily personal care",
      "Suitable For": "Adults",
      "Brand": "Nivea",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 201,
    "name": "Hemp Hand Protector",
    "brand": "The Body Shop",
    "category": "Beauty",
    "price": 799,
    "originalPrice": 1020,
    "discount": 22,
    "rating": 4.6,
    "reviewCount": 2058,
    "stock": 24,
    "description": "Hemp Hand Protector from The Body Shop, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal skin",
      "Ingredients": "Gentle personal-care formula",
      "Net Quantity": "Varies by product",
      "Benefits": "Daily personal care",
      "Suitable For": "Adults",
      "Brand": "The Body Shop",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 202,
    "name": "Fresh Active Deodorant",
    "brand": "Nivea",
    "category": "Beauty",
    "price": 249,
    "originalPrice": 280,
    "discount": 12,
    "rating": 3.8,
    "reviewCount": 2135,
    "stock": 59,
    "description": "Fresh Active Deodorant from Nivea, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal skin",
      "Ingredients": "Gentle personal-care formula",
      "Net Quantity": "Varies by product",
      "Benefits": "Daily personal care",
      "Suitable For": "Adults",
      "Brand": "Nivea",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 203,
    "name": "Yang Eau De Parfum",
    "brand": "Engage",
    "category": "Beauty",
    "price": 699,
    "originalPrice": 790,
    "discount": 12,
    "rating": 4.8,
    "reviewCount": 2099,
    "stock": 7,
    "description": "Yang Eau De Parfum from Engage, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal skin",
      "Ingredients": "Gentle personal-care formula",
      "Net Quantity": "Varies by product",
      "Benefits": "Daily personal care",
      "Suitable For": "Adults",
      "Brand": "Engage",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 204,
    "name": "Refreshing Cleansing Wipes",
    "brand": "Himalaya",
    "category": "Beauty",
    "price": 175,
    "originalPrice": 210,
    "discount": 15,
    "rating": 3.9,
    "reviewCount": 205,
    "stock": 22,
    "description": "Refreshing Cleansing Wipes from Himalaya, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal skin",
      "Ingredients": "Gentle personal-care formula",
      "Net Quantity": "Varies by product",
      "Benefits": "Daily personal care",
      "Suitable For": "Adults",
      "Brand": "Himalaya",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 205,
    "name": "Coffee Body Scrub",
    "brand": "MCaffeine",
    "category": "Beauty",
    "price": 449,
    "originalPrice": 500,
    "discount": 10,
    "rating": 4.2,
    "reviewCount": 1882,
    "stock": 11,
    "description": "Coffee Body Scrub from MCaffeine, selected for a practical everyday beauty routine. Check the pack for ingredient and expiry details.",
    "specifications": {
      "Skin Type": "Normal skin",
      "Ingredients": "Gentle personal-care formula",
      "Net Quantity": "Varies by product",
      "Benefits": "Daily personal care",
      "Suitable For": "Adults",
      "Brand": "MCaffeine",
      "Category": "Beauty"
    },
    "features": [
      "Product-specific beauty care",
      "Suitable for everyday routines",
      "Authentic-brand style listing"
    ],
    "image": "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 206,
    "name": "Electric Kettle 1.5L",
    "brand": "Prestige",
    "category": "Home & Kitchen",
    "price": 1299,
    "originalPrice": 1530,
    "discount": 15,
    "rating": 4.3,
    "reviewCount": 47,
    "stock": 63,
    "description": "Electric Kettle 1.5L by Prestige brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Prestige",
      "Category": "Home & Kitchen",
      "Model": "Electric Kettle 1.5L",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 207,
    "name": "Air Fryer 4.1L",
    "brand": "Philips",
    "category": "Home & Kitchen",
    "price": 6999,
    "originalPrice": 7780,
    "discount": 10,
    "rating": 4.5,
    "reviewCount": 304,
    "stock": 65,
    "description": "Air Fryer 4.1L by Philips brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Philips",
      "Category": "Home & Kitchen",
      "Model": "Air Fryer 4.1L",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 208,
    "name": "Microwave Glass Set",
    "brand": "Borosil",
    "category": "Home & Kitchen",
    "price": 899,
    "originalPrice": 1000,
    "discount": 10,
    "rating": 4.7,
    "reviewCount": 995,
    "stock": 31,
    "description": "Microwave Glass Set by Borosil brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Borosil",
      "Category": "Home & Kitchen",
      "Model": "Microwave Glass Set",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 209,
    "name": "Thermosteel Flask",
    "brand": "Milton",
    "category": "Home & Kitchen",
    "price": 799,
    "originalPrice": 1070,
    "discount": 25,
    "rating": 4.3,
    "reviewCount": 1600,
    "stock": 14,
    "description": "Thermosteel Flask by Milton brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Milton",
      "Category": "Home & Kitchen",
      "Model": "Thermosteel Flask",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 210,
    "name": "Stovekraft Mixer Grinder",
    "brand": "Pigeon",
    "category": "Home & Kitchen",
    "price": 2499,
    "originalPrice": 3050,
    "discount": 18,
    "rating": 4.6,
    "reviewCount": 846,
    "stock": 14,
    "description": "Stovekraft Mixer Grinder by Pigeon brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Pigeon",
      "Category": "Home & Kitchen",
      "Model": "Stovekraft Mixer Grinder",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 211,
    "name": "Fab Kettle",
    "brand": "Havells",
    "category": "Home & Kitchen",
    "price": 1599,
    "originalPrice": 1820,
    "discount": 12,
    "rating": 4.2,
    "reviewCount": 1280,
    "stock": 22,
    "description": "Fab Kettle by Havells brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Havells",
      "Category": "Home & Kitchen",
      "Model": "Fab Kettle",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 212,
    "name": "Basmati Rice 5kg",
    "brand": "India Gate",
    "category": "Grocery",
    "price": 699,
    "originalPrice": 930,
    "discount": 25,
    "rating": 3.9,
    "reviewCount": 1134,
    "stock": 17,
    "description": "Basmati Rice 5kg by India Gate brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "India Gate",
      "Category": "Grocery",
      "Model": "Basmati Rice 5kg",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 213,
    "name": "Atta 5kg",
    "brand": "Aashirvaad",
    "category": "Grocery",
    "price": 299,
    "originalPrice": 400,
    "discount": 25,
    "rating": 4.1,
    "reviewCount": 2149,
    "stock": 41,
    "description": "Atta 5kg by Aashirvaad brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Aashirvaad",
      "Category": "Grocery",
      "Model": "Atta 5kg",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 214,
    "name": "Salt 1kg",
    "brand": "Tata",
    "category": "Grocery",
    "price": 30,
    "originalPrice": 40,
    "discount": 25,
    "rating": 4.3,
    "reviewCount": 519,
    "stock": 75,
    "description": "Salt 1kg by Tata brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Tata",
      "Category": "Grocery",
      "Model": "Salt 1kg",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 215,
    "name": "Tea Gold 500g",
    "brand": "Tata",
    "category": "Grocery",
    "price": 299,
    "originalPrice": 360,
    "discount": 18,
    "rating": 4.9,
    "reviewCount": 1971,
    "stock": 7,
    "description": "Tea Gold 500g by Tata brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Tata",
      "Category": "Grocery",
      "Model": "Tea Gold 500g",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 216,
    "name": "Sunlite Refined Oil 1L",
    "brand": "Fortune",
    "category": "Grocery",
    "price": 159,
    "originalPrice": 210,
    "discount": 25,
    "rating": 3.9,
    "reviewCount": 2109,
    "stock": 62,
    "description": "Sunlite Refined Oil 1L by Fortune brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Fortune",
      "Category": "Grocery",
      "Model": "Sunlite Refined Oil 1L",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 217,
    "name": "Matic Liquid 2L",
    "brand": "Surf Excel",
    "category": "Grocery",
    "price": 349,
    "originalPrice": 450,
    "discount": 22,
    "rating": 4.0,
    "reviewCount": 897,
    "stock": 14,
    "description": "Matic Liquid 2L by Surf Excel brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Surf Excel",
      "Category": "Grocery",
      "Model": "Matic Liquid 2L",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 218,
    "name": "Kipsta Football",
    "brand": "Decathlon",
    "category": "Sports",
    "price": 799,
    "originalPrice": 890,
    "discount": 10,
    "rating": 4.0,
    "reviewCount": 2180,
    "stock": 38,
    "description": "Kipsta Football by Decathlon brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Decathlon",
      "Category": "Sports",
      "Model": "Kipsta Football",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 219,
    "name": "Mavis 350 Shuttlecock",
    "brand": "Yonex",
    "category": "Sports",
    "price": 999,
    "originalPrice": 1140,
    "discount": 12,
    "rating": 4.5,
    "reviewCount": 2117,
    "stock": 40,
    "description": "Mavis 350 Shuttlecock by Yonex brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Yonex",
      "Category": "Sports",
      "Model": "Mavis 350 Shuttlecock",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 220,
    "name": "Storm Basketball",
    "brand": "Nivia",
    "category": "Sports",
    "price": 899,
    "originalPrice": 1120,
    "discount": 20,
    "rating": 4.1,
    "reviewCount": 2025,
    "stock": 55,
    "description": "Storm Basketball by Nivia brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Nivia",
      "Category": "Sports",
      "Model": "Storm Basketball",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 221,
    "name": "Cricket Bat",
    "brand": "Cosco",
    "category": "Sports",
    "price": 1799,
    "originalPrice": 2040,
    "discount": 12,
    "rating": 3.8,
    "reviewCount": 2047,
    "stock": 62,
    "description": "Cricket Bat by Cosco brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Cosco",
      "Category": "Sports",
      "Model": "Cricket Bat",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 222,
    "name": "Training Mat",
    "brand": "Adidas",
    "category": "Sports",
    "price": 1299,
    "originalPrice": 1580,
    "discount": 18,
    "rating": 4.6,
    "reviewCount": 1738,
    "stock": 49,
    "description": "Training Mat by Adidas brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Adidas",
      "Category": "Sports",
      "Model": "Training Mat",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 223,
    "name": "Gym Duffle Bag",
    "brand": "Puma",
    "category": "Sports",
    "price": 1999,
    "originalPrice": 2500,
    "discount": 20,
    "rating": 3.9,
    "reviewCount": 1391,
    "stock": 5,
    "description": "Gym Duffle Bag by Puma brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Puma",
      "Category": "Sports",
      "Model": "Gym Duffle Bag",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 224,
    "name": "Air Purifier 1000i",
    "brand": "Philips",
    "category": "Electronics",
    "price": 9999,
    "originalPrice": 12500,
    "discount": 20,
    "rating": 4.7,
    "reviewCount": 525,
    "stock": 30,
    "description": "Air Purifier 1000i by Philips brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Philips",
      "Category": "Electronics",
      "Model": "Air Purifier 1000i",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1601944177325-f8867652837f?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1601944177325-f8867652837f?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 225,
    "name": "Smart LED TV 43-inch",
    "brand": "Mi",
    "category": "Electronics",
    "price": 28999,
    "originalPrice": 35360,
    "discount": 18,
    "rating": 4.1,
    "reviewCount": 300,
    "stock": 55,
    "description": "Smart LED TV 43-inch by Mi brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Mi",
      "Category": "Electronics",
      "Model": "Smart LED TV 43-inch",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 226,
    "name": "Soundbar HT-S40R",
    "brand": "Sony",
    "category": "Electronics",
    "price": 24990,
    "originalPrice": 27770,
    "discount": 10,
    "rating": 4.2,
    "reviewCount": 1787,
    "stock": 40,
    "description": "Soundbar HT-S40R by Sony brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Sony",
      "Category": "Electronics",
      "Model": "Soundbar HT-S40R",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1601944177325-f8867652837f?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1601944177325-f8867652837f?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 227,
    "name": "EOS R50 Camera",
    "brand": "Canon",
    "category": "Electronics",
    "price": 64999,
    "originalPrice": 79270,
    "discount": 18,
    "rating": 3.9,
    "reviewCount": 1203,
    "stock": 24,
    "description": "EOS R50 Camera by Canon brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Canon",
      "Category": "Electronics",
      "Model": "EOS R50 Camera",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 228,
    "name": "PartyBox Encore",
    "brand": "JBL",
    "category": "Electronics",
    "price": 24999,
    "originalPrice": 30490,
    "discount": 18,
    "rating": 4.3,
    "reviewCount": 1326,
    "stock": 29,
    "description": "PartyBox Encore by JBL brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "JBL",
      "Category": "Electronics",
      "Model": "PartyBox Encore",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1601944177325-f8867652837f?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1601944177325-f8867652837f?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 229,
    "name": "CO-W01 Projector",
    "brand": "Epson",
    "category": "Electronics",
    "price": 34999,
    "originalPrice": 44870,
    "discount": 22,
    "rating": 4.8,
    "reviewCount": 1672,
    "stock": 75,
    "description": "CO-W01 Projector by Epson brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Epson",
      "Category": "Electronics",
      "Model": "CO-W01 Projector",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  },
  {
    "id": 230,
    "name": "Leather Wallet",
    "brand": "Fossil",
    "category": "Accessories",
    "price": 2499,
    "originalPrice": 2940,
    "discount": 15,
    "rating": 4.6,
    "reviewCount": 236,
    "stock": 57,
    "description": "Leather Wallet by Fossil brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Fossil",
      "Category": "Accessories",
      "Model": "Leather Wallet",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Top Rated"
  },
  {
    "id": 231,
    "name": "Analog Watch",
    "brand": "Titan",
    "category": "Accessories",
    "price": 3499,
    "originalPrice": 3980,
    "discount": 12,
    "rating": 4.5,
    "reviewCount": 1206,
    "stock": 67,
    "description": "Analog Watch by Titan brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Titan",
      "Category": "Accessories",
      "Model": "Analog Watch",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Bestseller"
  },
  {
    "id": 232,
    "name": "Wayfarer Sunglasses",
    "brand": "Ray-Ban",
    "category": "Accessories",
    "price": 9990,
    "originalPrice": 11350,
    "discount": 12,
    "rating": 4.0,
    "reviewCount": 1733,
    "stock": 48,
    "description": "Wayfarer Sunglasses by Ray-Ban brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Ray-Ban",
      "Category": "Accessories",
      "Model": "Wayfarer Sunglasses",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "New"
  },
  {
    "id": 233,
    "name": "Leather Belt",
    "brand": "Tommy Hilfiger",
    "category": "Accessories",
    "price": 1999,
    "originalPrice": 2440,
    "discount": 18,
    "rating": 4.1,
    "reviewCount": 1099,
    "stock": 56,
    "description": "Leather Belt by Tommy Hilfiger brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Tommy Hilfiger",
      "Category": "Accessories",
      "Model": "Leather Belt",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 234,
    "name": "Luggage Tag",
    "brand": "Samsonite",
    "category": "Accessories",
    "price": 899,
    "originalPrice": 1100,
    "discount": 18,
    "rating": 4.3,
    "reviewCount": 1649,
    "stock": 20,
    "description": "Luggage Tag by Samsonite brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Samsonite",
      "Category": "Accessories",
      "Model": "Luggage Tag",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Trending"
  },
  {
    "id": 235,
    "name": "Jotter Pen Set",
    "brand": "Parker",
    "category": "Accessories",
    "price": 599,
    "originalPrice": 680,
    "discount": 12,
    "rating": 3.9,
    "reviewCount": 2084,
    "stock": 68,
    "description": "Jotter Pen Set by Parker brings dependable everyday performance and a polished shopping experience from FATHIMA MART.",
    "specifications": {
      "Brand": "Parker",
      "Category": "Accessories",
      "Model": "Jotter Pen Set",
      "Availability": "In stock"
    },
    "features": [
      "Quality checked",
      "Fast delivery options",
      "Easy returns on eligible items"
    ],
    "image": "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=82",
    "additionalImages": [
      "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=82"
    ],
    "badge": "Limited Offer"
  }
];

document.addEventListener("DOMContentLoaded",()=>{
 const app=fm.$("#app"), params=new URLSearchParams(location.search);
 let data=[...PRODUCTS];
 const q=(params.get("search")||"").trim().toLowerCase(), cat=params.get("category")||"";
 if(q)data=data.filter(p=>(p.name+" "+p.brand+" "+p.category).toLowerCase().includes(q));
 if(cat && cat!=="Fashion") data=data.filter(p=>p.category.toLowerCase()===cat.toLowerCase());
 if(cat==="Fashion") data=data.filter(p=>p.category.includes("Fashion"));
 app.innerHTML=`<div class="page-head"><div class="container"><h1>Shop Products</h1><p class="muted">${q?`Search results for “${q}”`:cat?cat:"Discover the FATHIMA MART collection"}</p></div></div>
 <div class="container layout"><aside class="filters"><h3>Filters</h3><div class="filter-group"><b>Search</b><input id="f-search" type="text" value="${q}" placeholder="Product or brand"></div>
 <div class="filter-group"><b>Category</b><select id="f-cat"><option value="">All categories</option>${[...new Set(PRODUCTS.map(p=>p.category))].map(c=>`<option ${c==cat?"selected":""}>${c}</option>`).join("")}</select></div>
 <div class="filter-group"><b>Brand</b><select id="f-brand"><option value="">All brands</option>${[...new Set(PRODUCTS.map(p=>p.brand))].sort().map(b=>`<option>${b}</option>`).join("")}</select></div>
 <div class="filter-group"><b>Price</b><div style="display:flex;gap:5px"><input id="min-price" type="number" placeholder="Min"><input id="max-price" type="number" placeholder="Max"></div></div>
 <div class="filter-group"><b>Minimum rating</b><select id="f-rating"><option value="">Any</option><option value="4">4★+</option><option value="4.5">4.5★+</option></select></div>
 <div class="filter-group"><label><input id="f-stock" type="checkbox"> In stock only</label><label><input id="f-discount" type="checkbox"> 15%+ discount</label></div><button class="btn outline" id="reset">Reset</button></aside>
 <section><div class="toolbar"><span id="count"></span><select id="sort"><option value="popular">Popular</option><option value="newest">Newest</option><option value="low">Price low to high</option><option value="high">Price high to low</option><option value="rating">Highest rated</option><option value="discount">Highest discount</option></select></div><div class="grid" id="products-grid"></div></section></div>`;
 const render=()=>{
   let d=[...PRODUCTS], s=fm.$("#f-search").value.toLowerCase(), c=fm.$("#f-cat").value, b=fm.$("#f-brand").value;
   if(s)d=d.filter(p=>(p.name+" "+p.brand+" "+p.category).toLowerCase().includes(s));
   if(c)d=d.filter(p=>p.category===c); if(b)d=d.filter(p=>p.brand===b);
   const min=+fm.$("#min-price").value||0,max=+fm.$("#max-price").value||Infinity;d=d.filter(p=>p.price>=min&&p.price<=max);
   const r=+fm.$("#f-rating").value||0;if(r)d=d.filter(p=>p.rating>=r);
   if(fm.$("#f-stock").checked)d=d.filter(p=>p.stock>0);if(fm.$("#f-discount").checked)d=d.filter(p=>p.discount>=15);
   const sort=fm.$("#sort").value;if(sort==="low")d.sort((a,b)=>a.price-b.price);if(sort==="high")d.sort((a,b)=>b.price-a.price);if(sort==="rating")d.sort((a,b)=>b.rating-a.rating);if(sort==="discount")d.sort((a,b)=>b.discount-a.discount);if(sort==="newest")d.sort((a,b)=>b.id-a.id);
   fm.$("#count").textContent=d.length+" products";fm.$("#products-grid").innerHTML=d.length?d.map(fm.productCard.bind(fm)).join(""):`<div class="empty" style="grid-column:1/-1"><h3>No products found</h3><p class="muted">Try another search, category or filter.</p></div>`;fm.bindCards(fm.$("#products-grid"));
 };
 ["f-search","f-cat","f-brand","min-price","max-price","f-rating","f-stock","f-discount","sort"].forEach(id=>fm.$("#"+id).addEventListener("input",render));fm.$("#reset").onclick=()=>location.href="products.html";render();
});
