
document.addEventListener("DOMContentLoaded",()=>{
 const orders=fm.get("fm_orders",[]),app=fm.$("#app");
 app.innerHTML=`<div class="page-head"><div class="container"><h1>My Orders</h1><p class="muted">Your demo order history</p></div></div><div class="container section">${orders.length?orders.map(o=>`<div class="admin-panel"><div style="display:flex;justify-content:space-between;gap:15px;flex-wrap:wrap"><div><b>${o.id}</b><p class="muted">${new Date(o.date).toLocaleString("en-IN")}</p></div><div><strong>${fm.money(o.total)}</strong><p class="muted">${o.payment} • ${o.status}</p></div><div><a class="btn outline" href="order-details.html?id=${o.id}">View order</a> <a class="btn primary" href="tracking.html?id=${o.id}">Track</a></div></div></div>`).join(""):`<div class="empty"><h2>No orders yet</h2><a class="btn primary" href="products.html">Shop now</a></div>`}</div>`;
});
