
document.addEventListener("DOMContentLoaded",()=>{
 const id=new URLSearchParams(location.search).get("id"),o=fm.get("fm_orders",[]).find(x=>x.id===id)||fm.get("fm_orders",[])[0],app=fm.$("#app");if(!o){location.href="orders.html";return}
 const states=["Order Confirmed","Order Packed","Shipped","Out for Delivery","Delivered"],idx=Math.max(0,states.indexOf(o.status));
 app.innerHTML=`<div class="page-head"><div class="container"><h1>Track Order</h1><p class="muted">${o.id} • ${o.trackingId}</p></div></div><div class="container section"><div class="admin-panel"><div style="display:flex;justify-content:space-between"><div><b>${o.partner}</b><p class="muted">Tracking ID: ${o.trackingId}</p></div><div><b>${o.status}</b><p class="muted">ETA ${new Date(o.estimatedDelivery).toLocaleDateString("en-IN")}</p></div></div><div class="timeline">${states.map((s,i)=>`<div class="step ${i<=idx?'done':''}"><span class="dot">${i<=idx?'✓':i+1}</span><b>${s}</b></div>`).join("")}</div><div class="promo"><div><h3>Demo location</h3><p class="muted">Sample route: Chennai → Bengaluru → Delivery hub</p></div><div style="font-size:48px">📍</div></div></div></div>`;
});
