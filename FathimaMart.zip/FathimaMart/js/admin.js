
document.addEventListener("DOMContentLoaded",()=>{
 const u=fm.user();if(!u||u.role!=="admin"){location.href="login.html";return}
 const app=fm.$("#app");let orders=fm.get("fm_orders",[]),users=fm.get("fm_users",[]);
 function render(){const revenue=orders.reduce((s,o)=>s+o.total,0),pending=orders.filter(o=>o.status!=="Delivered").length,low=PRODUCTS.filter(p=>p.stock<10).length;
 app.innerHTML=`<div class="admin-shell"><div class="container"><div class="admin-top"><div><h1>Admin Dashboard</h1><p class="muted">FATHIMA MART demo management</p></div><button class="btn outline" id="logout">Logout</button></div>
 <div class="dashboard"><div class="stat">Products<strong>${PRODUCTS.length}</strong></div><div class="stat">Orders<strong>${orders.length}</strong></div><div class="stat">Users<strong>${users.length+1}</strong></div><div class="stat">Revenue<strong>${fm.money(revenue)}</strong></div><div class="stat">Pending<strong>${pending}</strong></div><div class="stat">Low stock<strong>${low}</strong></div></div>
 <div class="admin-panel"><h3>Recent Orders</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Amount</th><th>Status</th><th>Update</th></tr></thead><tbody>${orders.slice(0,12).map(o=>`<tr><td>${o.id}</td><td>${o.address.name}</td><td>${new Date(o.date).toLocaleDateString("en-IN")}</td><td>${fm.money(o.total)}</td><td>${o.status}</td><td><select data-status="${o.id}">${["Order Confirmed","Order Packed","Shipped","Out for Delivery","Delivered"].map(s=>`<option ${s===o.status?"selected":""}>${s}</option>`).join("")}</select></td></tr>`).join("")||`<tr><td colspan="6">No orders yet</td></tr>`}</tbody></table></div></div>
 <div class="admin-panel"><h3>Product Management</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Image</th><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th></tr></thead><tbody>${PRODUCTS.slice(0,40).map(p=>`<tr><td><img src="${p.image}" style="width:40px;height:40px;object-fit:cover;border-radius:7px"></td><td>${p.name}</td><td>${p.category}</td><td>${fm.money(p.price)}</td><td>${p.stock}</td><td>${p.stock>0?"Active":"Out of stock"}</td></tr>`).join("")}</tbody></table></div></div>
 </div></div>`;
 fm.$("#logout").onclick=()=>{localStorage.removeItem("fm_session");location.href="index.html"};
 fm.$$("[data-status]").forEach(s=>s.onchange=()=>{const o=orders.find(x=>x.id===s.dataset.status);if(o){o.status=s.value;fm.set("fm_orders",orders);fm.toast("Order status updated");render()}});
 }
 render();
});
