
(function(){
  const $ = (s,r=document)=>r.querySelector(s);
  const $$ = (s,r=document)=>[...r.querySelectorAll(s)];
  window.fm = {
    $,$$,
    get(k,d){ try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch(e){ return d; } },
    set(k,v){ localStorage.setItem(k,JSON.stringify(v)); },
    money(n){ return "₹" + Number(n||0).toLocaleString("en-IN"); },
    toast(msg,type="success"){
      let box=$("#toast-container");
      if(!box){ box=document.createElement("div"); box.id="toast-container"; document.body.appendChild(box); }
      const t=document.createElement("div"); t.className="toast "+type; t.textContent=msg; box.appendChild(t);
      setTimeout(()=>t.classList.add("show"),10); setTimeout(()=>{t.classList.remove("show");setTimeout(()=>t.remove(),250)},2800);
    },
    cart(){ return this.get("fm_cart",[]); },
    wishlist(){ return this.get("fm_wishlist",[]); },
    user(){ return this.get("fm_session",null); },
    find(id){ return (window.PRODUCTS||[]).find(p=>p.id==id); },
    addCart(id,qty=1){
      const c=this.cart(), p=this.find(id); if(!p) return;
      const item=c.find(x=>x.id==id);
      if(item) item.qty=Math.min(item.qty+qty,99); else c.push({id:Number(id),qty});
      this.set("fm_cart",c); this.updateHeader(); this.toast("Added to cart");
    },
    removeCart(id){this.set("fm_cart",this.cart().filter(x=>x.id!=id));this.updateHeader()},
    setQty(id,qty){const c=this.cart();const i=c.find(x=>x.id==id);if(i){i.qty=Math.max(1,Math.min(99,qty));this.set("fm_cart",c);this.updateHeader()}},
    toggleWish(id){
      let w=this.wishlist(); id=Number(id);
      if(w.includes(id)){w=w.filter(x=>x!==id);this.toast("Removed from wishlist","info")}else{w.push(id);this.toast("Added to wishlist")}
      this.set("fm_wishlist",w); this.updateHeader(); return w.includes(id);
    },
    updateHeader(){
      const c=this.cart().reduce((s,x)=>s+x.qty,0), w=this.wishlist().length;
      $$(".cart-count").forEach(e=>e.textContent=c); $$(".wish-count").forEach(e=>e.textContent=w);
      const u=this.user(); $$(".user-name").forEach(e=>e.textContent=u?u.name:"Login");
    },
    requireLogin(){ if(!this.user()){location.href="login.html?next="+encodeURIComponent(location.pathname+location.search);return false} return true;},
    imgFallback(img){ img.onerror=()=>{img.onerror=null;img.src="https://placehold.co/700x700?text=FATHIMA+MART";}; },
    productCard(p){
      const wished=this.wishlist().includes(p.id);
      return `<article class="product-card">
        <div class="product-img-wrap"><span class="badge">${p.badge}</span><button class="wish-btn ${wished?'active':''}" data-wish="${p.id}" aria-label="Wishlist">♡</button>
        <a href="product-details.html?id=${p.id}"><img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.onerror=null;this.src='https://placehold.co/700x700?text=FATHIMA+MART'"></a></div>
        <div class="product-info"><small>${p.brand}</small><h3><a href="product-details.html?id=${p.id}">${p.name}</a></h3>
        <div class="rating">★ ${p.rating} <span>(${p.reviewCount})</span></div>
        <div class="price-row"><strong>${this.money(p.price)}</strong><del>${this.money(p.originalPrice)}</del><em>${p.discount}% off</em></div>
        <div class="stock ${p.stock<10?'low':''}">${p.stock<10?'Only '+p.stock+' left':'In stock'}</div>
        <button class="btn primary add-cart" data-add="${p.id}">Add to Cart</button></div></article>`;
    },
    bindCards(root=document){
      $$(".add-cart",root).forEach(b=>b.onclick=()=>this.addCart(b.dataset.add));
      $$(".wish-btn",root).forEach(b=>b.onclick=()=>{const active=this.toggleWish(b.dataset.wish);b.classList.toggle("active",active)});
    },
    initHeader(){
      const header=$("#site-header"); if(!header)return;
      header.innerHTML=`<div class="announcement">Free delivery on orders above ₹999 • Easy returns on eligible products</div>
      <nav class="navbar"><a class="logo" href="index.html"><span>F</span> FATHIMA <b>MART</b></a>
      <button class="menu-toggle" id="menu-toggle">☰</button>
      <div class="search-box"><input id="global-search" placeholder="Search products, brands and categories"><button id="global-search-btn">⌕</button></div>
      <div class="nav-actions"><a href="login.html">👤 <span class="user-name">Login</span></a><a href="wishlist.html">♡ <i class="wish-count">0</i></a><a href="cart.html">🛒 <i class="cart-count">0</i></a></div></nav>
      <div class="category-nav" id="category-nav"><a href="products.html">All</a>${["Mobiles","Laptops","Beauty","Fashion","Shoes","Home & Kitchen","Grocery","Gaming","Sports"].map(c=>`<a href="products.html?category=${encodeURIComponent(c)}">${c}</a>`).join("")}</div>`;
      $("#global-search-btn").onclick=()=>this.searchGo();
      $("#global-search").addEventListener("keydown",e=>{if(e.key==="Enter")this.searchGo()});
      $("#menu-toggle").onclick=()=>$("#category-nav").classList.toggle("open");
      this.updateHeader();
    },
    searchGo(){const q=$("#global-search")?.value.trim();if(q)location.href="products.html?search="+encodeURIComponent(q)},
    init(){
      this.initHeader();
      $$(".back-top").forEach(b=>b.onclick=()=>scrollTo({top:0,behavior:"smooth"}));
      window.addEventListener("scroll",()=>{$(".back-top")?.classList.toggle("show",scrollY>500)});
    }
  };
  document.addEventListener("DOMContentLoaded",fm.init);
})();


document.addEventListener("DOMContentLoaded",()=>{
 const app=fm.$("#app");
 const cats=[["📱","Mobiles"],["💻","Laptops"],["💄","Beauty"],["👗","Women's Fashion"],["👟","Shoes"],["🛒","Grocery"],["🎮","Gaming"],["🏠","Home & Kitchen"],["⌚","Smart Watches"],["🎧","Headphones"],["⚽","Sports"],["🎒","Bags"]];
 const picks=[...PRODUCTS].filter(p=>["Bestseller","Trending","Top Rated"].includes(p.badge)).slice(0,8);
 const beauty=PRODUCTS.filter(p=>p.category==="Beauty").slice(0,6);
 const deals=[...PRODUCTS].sort((a,b)=>b.discount-a.discount).slice(0,8);
 const trending=[...PRODUCTS].sort((a,b)=>b.rating-a.rating).slice(0,8);
 const viewed=fm.get("fm_recent",[]).map(id=>fm.find(id)).filter(Boolean).slice(0,4);
 app.innerHTML=`<section class="hero"><div class="hero-copy"><span class="eyebrow">Fathima Mart • Everyday premium shopping</span><h1>Everything you need. One beautiful marketplace.</h1><p>Discover smart tech, fashion, beauty essentials, groceries and more with a polished shopping experience designed for modern India.</p><a class="btn light" href="products.html">Shop all products →</a></div></section>
 <section class="section container"><div class="section-head"><h2>Shop by Category</h2><a href="products.html">View all</a></div><div class="categories">${cats.map(c=>`<a class="cat" href="products.html?category=${encodeURIComponent(c[1])}"><span>${c[0]}</span>${c[1]}</a>`).join("")}</div></section>
 <section class="section container"><div class="section-head"><h2>Today's Deals</h2><a href="products.html?sort=discount">See deals</a></div><div class="grid" id="deals"></div></section>
 <section class="section container"><div class="promo"><div><span class="eyebrow">Beauty edit</span><h3>Beauty Essentials</h3><p class="muted">Skincare, makeup, haircare and personal care picks.</p></div><a class="btn primary" href="products.html?category=Beauty">Explore Beauty</a></div><div class="grid" id="beauty" style="margin-top:18px"></div></section>
 <section class="section container"><div class="section-head"><h2>Best Sellers</h2><a href="products.html">Explore</a></div><div class="grid" id="best"></div></section>
 <section class="section container"><div class="section-head"><h2>Trending Now</h2></div><div class="grid" id="trend"></div></section>
 <section class="section container"><div class="promo"><div><span class="eyebrow">Smart shopping</span><h3>Up to 25% off selected picks</h3><p class="muted">Fresh deals across tech, home, fashion and beauty.</p></div><a class="btn primary" href="products.html">Browse deals</a></div></section>
 ${viewed.length?`<section class="section container"><div class="section-head"><h2>Recently Viewed</h2></div><div class="grid" id="recent"></div></section>`:""}
 <section class="section container"><div class="promo"><div><h3>Get Fathima Mart updates</h3><p class="muted">New arrivals, offers and curated collections.</p></div><div class="newsletter" style="min-width:320px"><input id="home-email" placeholder="Your email"><button id="home-sub">Subscribe</button></div></div></section>`;
 const render=(id,arr)=>{fm.$("#"+id).innerHTML=arr.map(fm.productCard.bind(fm)).join("");fm.bindCards(fm.$("#"+id))};
 render("deals",deals);render("beauty",beauty);render("best",picks);render("trend",trending);if(viewed.length)render("recent",viewed);
 fm.$("#home-sub").onclick=()=>fm.toast("Thanks for subscribing!");
});
