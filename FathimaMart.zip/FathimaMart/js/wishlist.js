
document.addEventListener("DOMContentLoaded",()=>{
 const app=fm.$("#app"),ids=fm.wishlist(),items=ids.map(id=>fm.find(id)).filter(Boolean);
 app.innerHTML=`<div class="page-head"><div class="container"><h1>Wishlist</h1><p class="muted">${items.length} saved product(s)</p></div></div><div class="container section">${items.length?`<div class="grid" id="wish-grid"></div>`:`<div class="empty"><h2>Your wishlist is empty</h2><a class="btn primary" href="products.html">Discover products</a></div>`}</div>`;
 if(items.length){fm.$("#wish-grid").innerHTML=items.map(fm.productCard.bind(fm)).join("");fm.bindCards(fm.$("#wish-grid"));fm.$$("#wish-grid .wish-btn").forEach(b=>b.onclick=()=>{fm.toggleWish(b.dataset.wish);location.reload()})}
});
