
document.addEventListener("DOMContentLoaded",()=>{
 const app=fm.$("#app");
 function render(){
  const c=fm.cart(), items=c.map(x=>({...x,p:fm.find(x.id)})).filter(x=>x.p);
  if(!items.length){app.innerHTML=`<div class="container section"><div class="empty"><h2>Your cart is empty</h2><p class="muted">Add something you love and it will stay here.</p><a class="btn primary" href="products.html">Start shopping</a></div></div>`;return}
  const sub=items.reduce((s,x)=>s+x.p.price*x.qty,0), discount=fm.get("fm_coupon_discount",0), delivery=sub>=999?0:79,total=Math.max(0,sub-discount+delivery);
  app.innerHTML=`<div class="page-head"><div class="container"><h1>Your Cart</h1><p class="muted">${items.reduce((s,x)=>s+x.qty,0)} item(s)</p></div></div><div class="container cart-layout"><section><div id="cart-items">${items.map(x=>`<div class="cart-item"><img src="${x.p.image}" onerror="this.onerror=null;this.src='https://placehold.co/200?text=FM'"><div><b>${x.p.name}</b><small style="display:block;color:#6b746f">${x.p.brand}</small><strong>${fm.money(x.p.price)}</strong><div class="qty" style="margin-top:8px"><button data-dec="${x.id}">−</button><input value="${x.qty}" data-qty="${x.id}"><button data-inc="${x.id}">+</button></div></div><div><button class="btn danger" data-remove="${x.id}">Remove</button><button class="btn outline" data-wish="${x.id}" style="margin-left:5px">♡</button></div></div>`).join("")}</div><a class="btn outline" href="products.html">← Continue shopping</a></section><aside class="summary"><h3>Order Summary</h3><div class="coupon"><input id="coupon" placeholder="Coupon code"><button id="apply">Apply</button></div><div id="coupon-msg" class="muted" style="font-size:12px"></div><div class="sum-row"><span>Subtotal</span><b>${fm.money(sub)}</b></div><div class="sum-row"><span>Discount</span><b>− ${fm.money(discount)}</b></div><div class="sum-row"><span>Delivery</span><b>${delivery?fm.money(delivery):"FREE"}</b></div><div class="sum-row sum-total"><span>Total</span><b>${fm.money(total)}</b></div><a class="btn primary" style="width:100%;text-align:center;margin-top:12px" href="checkout.html">Proceed to Checkout</a></aside></div>`;
  fm.$$("#cart-items [data-remove]").forEach(b=>b.onclick=()=>{fm.removeCart(b.dataset.remove);render()});
  fm.$$("#cart-items [data-dec]").forEach(b=>b.onclick=()=>{fm.setQty(b.dataset.dec,(fm.cart().find(x=>x.id==b.dataset.dec)?.qty||1)-1);render()});
  fm.$$("#cart-items [data-inc]").forEach(b=>b.onclick=()=>{fm.setQty(b.dataset.inc,(fm.cart().find(x=>x.id==b.dataset.inc)?.qty||1)+1);render()});
  fm.$$("#cart-items [data-wish]").forEach(b=>b.onclick=()=>fm.toggleWish(b.dataset.wish));
  fm.$("#apply").onclick=()=>{const code=fm.$("#coupon").value.trim().toUpperCase();let d=0;if(code==="NETHRA10"||code==="FATHIMA10")d=Math.min(sub*.10,1000);else if(code==="SAVE200")d=Math.min(200,sub);else if(code==="WELCOME")d=Math.min(150,sub*.08);else{fm.toast("Invalid coupon","error");return}fm.set("fm_coupon_discount",Math.round(d));fm.toast("Coupon applied");render()};
 }
 render();
});
