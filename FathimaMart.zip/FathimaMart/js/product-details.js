
document.addEventListener("DOMContentLoaded",()=>{
 const id=Number(new URLSearchParams(location.search).get("id")), p=fm.find(id), app=fm.$("#app");
 if(!p){location.href="404.html";return}
 let recent=fm.get("fm_recent",[]).filter(x=>x!==id);recent.unshift(id);fm.set("fm_recent",recent.slice(0,8));
 const related=PRODUCTS.filter(x=>x.category===p.category&&x.id!==p.id).slice(0,4);
 app.innerHTML=`<div class="container"><div class="page-head" style="margin-left:-4.2%;margin-right:-4.2%"><div class="container"><p><a href="products.html">Products</a> / ${p.category}</p></div></div>
 <section class="detail"><div class="detail-gallery"><div class="thumbs">${[p.image,...p.additionalImages].map((im,i)=>`<img class="${i===0?'active':''}" src="${im}" data-img="${im}" onerror="this.onerror=null;this.src='https://placehold.co/700x700?text=FATHIMA+MART'">`).join("")}</div><div class="detail-main"><img id="main-img" src="${p.image}" alt="${p.name}" onerror="this.onerror=null;this.src='https://placehold.co/700x700?text=FATHIMA+MART'"></div></div>
 <div><small class="muted">${p.brand} • ${p.category}</small><h1>${p.name}</h1><div class="rating">★ ${p.rating} <span>(${p.reviewCount} reviews)</span></div><p>${p.description}</p><div class="price">${fm.money(p.price)} <del style="font-size:14px;color:#899">${fm.money(p.originalPrice)}</del> <em style="font-size:13px;color:#287a59">${p.discount}% off</em></div><p class="stock ${p.stock<10?'low':''}">${p.stock>0?"In stock • "+p.stock+" available":"Out of stock"}</p>
 <div class="detail-actions"><div class="qty"><button id="minus">−</button><input id="qty" value="1" min="1" max="${p.stock}"><button id="plus">+</button></div><button class="btn primary" id="add">Add to Cart</button><button class="btn outline" id="wish">♡ Wishlist</button></div><button class="btn primary" id="buy" style="width:100%">Buy Now</button>
 <div class="specs"><h3>Specifications</h3>${Object.entries(p.specifications).map(([k,v])=>`<div class="spec-row"><b>${k}</b><span>${v}</span></div>`).join("")}</div><div class="specs"><h3>Features</h3><ul>${p.features.map(x=>`<li>${x}</li>`).join("")}</ul></div></div></section>
 <section class="section"><h2>Customer Reviews</h2><div class="review"><b>Verified shopper</b> <span class="rating">★ ${p.rating}</span><p class="muted">A popular choice with ${p.reviewCount.toLocaleString("en-IN")} recorded reviews.</p></div></section>
 <section class="section"><div class="section-head"><h2>Related Products</h2></div><div class="grid" id="related"></div></section></div>`;
 fm.$("#plus").onclick=()=>fm.$("#qty").value=Math.min(p.stock,+fm.$("#qty").value+1);fm.$("#minus").onclick=()=>fm.$("#qty").value=Math.max(1,+fm.$("#qty").value-1);
 fm.$("#add").onclick=()=>fm.addCart(id,+fm.$("#qty").value);fm.$("#buy").onclick=()=>{fm.addCart(id,+fm.$("#qty").value);location.href="checkout.html"};
 fm.$("#wish").onclick=()=>{const a=fm.toggleWish(id);fm.$("#wish").textContent=a?"♥ Wishlisted":"♡ Wishlist"};
 fm.$$(".thumbs img").forEach(t=>t.onclick=()=>{fm.$("#main-img").src=t.dataset.img;fm.$$(".thumbs img").forEach(x=>x.classList.remove("active"));t.classList.add("active")});
 fm.$("#related").innerHTML=related.map(fm.productCard.bind(fm)).join("");fm.bindCards(fm.$("#related"));
});
