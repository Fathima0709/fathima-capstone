# FATHIMA MART

Professional pure-frontend e-commerce demo.

## Stack
HTML5, CSS3, Vanilla JavaScript, JavaScript product data, localStorage and external product imagery. No backend, database, Node.js, PHP, Java, JSP, Servlets, Maven, Tomcat or Spring.

## Product catalog
135 products across 18 categories, including a developed Beauty collection with skincare, makeup, haircare and personal care.

## Demo credentials
- Admin: admin@fathimamart.demo
- Password: admin123

Regular users can register from the website. Authentication is demo-only and stored in localStorage.

## Run
1. Open the `FathimaMart` folder in VS Code.
2. Install the Live Server extension if needed.
3. Right-click `index.html` → **Open with Live Server**.
4. Internet access is recommended for the external product images and Google font. A fallback placeholder appears if an image fails.

## Main features
- Responsive homepage, product listing and product details
- Global search, category/brand/price/rating/stock/discount filters
- Sorting
- Cart and wishlist persistence
- Demo login/register/profile
- Coupon support: NETHRA10, SAVE200, WELCOME, FATHIMA10
- Frontend-only checkout and localStorage order creation
- Order history, order details and demo tracking
- Admin dashboard with demo order status management
- Toasts, empty states, fallback images and mobile navigation

## Note
Payments, authentication, inventory and admin security are intentionally demo-only because this is a pure frontend project.
